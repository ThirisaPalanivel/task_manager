package com.example.task;

import static androidx.constraintlayout.motion.widget.TransitionBuilder.validate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class CreateAccount extends AppCompatActivity {


    EditText e,p,r;
    Button c ;
    ProgressBar pr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
         e= findViewById(R.id.e_id);
         p = findViewById(R.id.s_pass);
         r = findViewById(R.id.s_repass);
         c = findViewById(R.id.s_create);
        c.setOnClickListener(v-> note());

    }



    public void note() {


        String email = e.getText().toString();
        String password = p.getText().toString();
        String re_pass = r.getText().toString();

        boolean isValidated = validate(email, password, re_pass);
        if (isValidated == false) {
            return;
        }

        CreateAccountFirebase(email, password);
    }
    public void lo(View v)
    {
        Intent i= new Intent(CreateAccount.this,LoginActivity.class);
        startActivity(i);
        finish();

    }

            void CreateAccountFirebase(String email,String password)
        {
       //changeProgress(true);
            FirebaseAuth f=FirebaseAuth.getInstance();
            f.createUserWithEmailAndPassword( email,password).addOnCompleteListener(CreateAccount.this,
                    new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            //changeProgress(false);
                            if (task.isSuccessful()) {
                                Toast.makeText(CreateAccount.this, "Successfully verified", Toast.LENGTH_LONG).show();
                                f.getCurrentUser().sendEmailVerification();
                                f.signOut();
                            } else {
                                Toast.makeText(CreateAccount.this, task.getException().getLocalizedMessage(), Toast.LENGTH_LONG).show();
                            }
                        }


        });
    }

    /*void changeProgress(boolean inProgress)
    {
        if(inProgress)
        {
            p.setVisibility(View.VISIBLE);
            c.setVisibility(View.GONE);

        }
        else
        {
            p.setVisibility(View.GONE);
            c.setVisibility(View.VISIBLE);

        }
    }*/

    boolean validate(String email, String password, String re_pass) {
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(CreateAccount.this,"invalid email id",Toast.LENGTH_SHORT).show();
            e.setError("invalid email");

            return false;
        }
        if (!(password.length() > 5)) {
            p.setError("password must contains 6 digit");
            Toast.makeText(CreateAccount.this,"password must contains 6 digit",Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!password.equals(re_pass)) {
            r.setError("invalid password");
            Toast.makeText(CreateAccount.this,"re enter the password correctly",Toast.LENGTH_SHORT).show();
            return false;
        }

     return true;
    }
}