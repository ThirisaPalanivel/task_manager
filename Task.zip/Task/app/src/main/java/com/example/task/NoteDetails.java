package com.example.task;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;

public class NoteDetails extends AppCompatActivity {

    EditText titleEditText,contentEditText;
    ImageButton saveNoteBtn;
    TextView pageTitleTextView;
    String title,content,docId;
    boolean isEditMode = false;
    ImageButton deleteNoteTextViewBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_details);

        titleEditText = findViewById(R.id.ti_id);
        contentEditText = findViewById(R.id.de_id);
        saveNoteBtn = findViewById(R.id.save_btn);
        pageTitleTextView = findViewById(R.id.add_title);
        deleteNoteTextViewBtn  = findViewById(R.id.del_btn);

        //receive data
        title = getIntent().getStringExtra("title");
        content= getIntent().getStringExtra("content");
        docId = getIntent().getStringExtra("docId");

        if(docId!=null && !docId.isEmpty()){
            isEditMode = true;
        }

        titleEditText.setText(title);
        contentEditText.setText(content);
        if(isEditMode){
            pageTitleTextView.setText("Edit your note");
            deleteNoteTextViewBtn.setVisibility(View.VISIBLE);
        }

        saveNoteBtn.setOnClickListener( (v)-> saveNote());

        deleteNoteTextViewBtn.setOnClickListener((v)-> deleteNoteFromFirebase() );

    }

    public void saveNote() {
        String noteTitle = titleEditText.getText().toString();
        String noteContent = contentEditText.getText().toString();
        if (noteTitle == null || noteTitle.isEmpty()) {
            titleEditText.setError("Title is required");
            return;
        }
        Notes note = new Notes();
        note.setTitle(noteTitle);
        note.setDescription(noteContent);
        note.setTimestamp(Timestamp.now());


        saveNoteToFirebase(note);
    }


        void saveNoteToFirebase (Notes note){
            DocumentReference documentReference;
            if (isEditMode) {
                //update the note
                documentReference = Utility.getcollection().document(docId);
            } else {
                //create new note
                documentReference = Utility.getcollection().document();
                docId = documentReference.getId();
            }


            documentReference.set(note).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        //note is added
                        Toast.makeText(NoteDetails.this, "Note added successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(NoteDetails.this, "!!!Failed while adding note", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }


    void deleteNoteFromFirebase(){
        DocumentReference documentReference;
        documentReference = Utility.getcollection().document(docId);
        documentReference.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    //note is deleted
                    Toast.makeText(NoteDetails.this,"Note deleted successfully",Toast.LENGTH_SHORT).show();
                    finish();
                }else{
                    Toast.makeText(NoteDetails.this,"Failed while deleting note",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


}