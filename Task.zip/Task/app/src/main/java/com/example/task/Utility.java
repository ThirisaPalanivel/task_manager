package com.example.task;

import android.os.Build;

import androidx.annotation.RequiresApi;

import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Utility {

    static CollectionReference getcollection(){
        FirebaseUser currentUser= FirebaseAuth.getInstance().getCurrentUser();
        FirebaseFirestore.getInstance().collection("notes").document(currentUser.getUid()).collection("MyNotes");
        if (currentUser != null) {
            return FirebaseFirestore.getInstance()
                    .collection("notes")
                    .document(currentUser.getUid())
                    .collection("MyNotes");
        } else {
            return null;
        }
    }
    public static String timestampToString(Timestamp timestamp) {
        if (timestamp != null) {
            Date date = timestamp.toDate();
            SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yy", Locale.getDefault());
            return sdf.format(date);
        } else {
            return "";
        }
    }
}
