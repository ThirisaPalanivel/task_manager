package com.example.task;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    EditText e,p;
    Button l ;
    ProgressBar pro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        e= findViewById(R.id.l_id);
        p=findViewById(R.id.l_pass);
        l = findViewById(R.id.l_create);
        l.setOnClickListener(view -> here());

    }

    public void sign(View v) {
        Intent i= new Intent(LoginActivity.this,CreateAccount.class);
        startActivity(i);
        finish();

    }
    private void here() {
        String email = e.getText().toString();
        String password = p.getText().toString();

        boolean isValidated = validate(email, password);
        if (isValidated == false) {
            return;
        }

        CreateLoginFirebase(email, password);
    }

    void CreateLoginFirebase(String email,String password)
    {
        //changeProgress(true);
        FirebaseAuth f=FirebaseAuth.getInstance();
        f.signInWithEmailAndPassword(email,password).addOnCompleteListener(
                new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        //changeProgress(false);
                        if (task.isSuccessful()) {
                            if (f.getCurrentUser().isEmailVerified()) {

                                Intent i = new Intent(LoginActivity.this, AddNote.class);
                                startActivity(i);
                                finish();
                                Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_LONG).show();


                            }

                        } else {
                            Toast.makeText(LoginActivity.this, task.getException().getLocalizedMessage(), Toast.LENGTH_LONG).show();
                        }
                    }

                });
    }

    /*void changeProgress(boolean inProgress)
    {
        if(inProgress)
        {
            p.setVisibility(View.VISIBLE);
            c.setVisibility(View.GONE);

        }
        else
        {
            p.setVisibility(View.GONE);
            c.setVisibility(View.VISIBLE);

        }
    }*/

    boolean validate(String email, String password) {
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(LoginActivity.this,"invalid email id",Toast.LENGTH_SHORT).show();
            e.setError("invalid email");

            return false;
        }
        if (!(password.length() > 5)) {
            p.setError("password must contains 6 digit");
            Toast.makeText(LoginActivity.this,"password must contains 6 digit",Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}

